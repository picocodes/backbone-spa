# backbone-spa
This WordPress theme converts your existing WordPress website into a single page application.
